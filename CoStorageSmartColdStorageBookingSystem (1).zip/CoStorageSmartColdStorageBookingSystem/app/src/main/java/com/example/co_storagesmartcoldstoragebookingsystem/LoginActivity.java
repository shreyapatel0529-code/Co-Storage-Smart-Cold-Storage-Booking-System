
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class LoginActivity extends AppCompatActivity {

    EditText etEmail, etPassword;
    Button btnLogin, btnRegister, btnForgotPassword;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new DatabaseHelper(this);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        btnForgotPassword = findViewById(R.id.btnForgotPassword);

        btnLogin.setOnClickListener(v -> loginUser());

        btnRegister.setOnClickListener(v -> {
            startActivity(new Intent(
                    LoginActivity.this, RegisterActivity.class));
        });

        btnForgotPassword.setOnClickListener(v -> {
            startActivity(new Intent(
                    LoginActivity.this, ForgotPasswordActivity.class));
        });
    }

    private void loginUser() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter email and password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Enter a valid email");
            return;
        }

        String enteredHash = hashPassword(password);

        if (enteredHash == null) {
            Toast.makeText(this, "Unable to verify password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        try (Cursor cursor = databaseHelper.getUserByEmail(email)) {

            if (cursor == null || !cursor.moveToFirst()) {
                Toast.makeText(this, "Incorrect email or password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            int userId = cursor.getInt(
                    cursor.getColumnIndexOrThrow("id"));

            String savedHash = cursor.getString(
                    cursor.getColumnIndexOrThrow("password_hash"));

            String role = cursor.getString(
                    cursor.getColumnIndexOrThrow("role"));

            if (savedHash == null ||
                    !MessageDigest.isEqual(
                            enteredHash.getBytes(StandardCharsets.UTF_8),
                            savedHash.getBytes(StandardCharsets.UTF_8))) {

                Toast.makeText(this, "Incorrect email or password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            getSharedPreferences("CoStorageSession", MODE_PRIVATE)
                    .edit()
                    .putInt("user_id", userId)
                    .putString("role", role)
                    .apply();

            Toast.makeText(this, "Login successful!",
                    Toast.LENGTH_SHORT).show();

            Intent intent;

            if ("Farmer".equalsIgnoreCase(role)) {
                intent = new Intent(this, FarmerHomeActivity.class);
            } else if ("Cold Storage Owner".equalsIgnoreCase(role)
                    || "Owner".equalsIgnoreCase(role)) {
                intent = new Intent(this, OwnerDashboardActivity.class);
            } else {
                Toast.makeText(this, "Invalid account role",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            startActivity(intent);
            finish();

        } catch (Exception e) {
            Toast.makeText(this, "Login failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(
                    password.getBytes(StandardCharsets.UTF_8));

            StringBuilder result = new StringBuilder();

            for (byte b : bytes) {
                result.append(String.format("%02x", b & 0xff));
            }

            return result.toString();

        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }
}
