
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateSpaceActivity extends AppCompatActivity {

    EditText etTotalCapacity, etOccupiedSpace;
    TextView tvAvailableSpace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_space);

        etTotalCapacity = findViewById(R.id.etTotalCapacity);
        etOccupiedSpace = findViewById(R.id.etOccupiedSpace);
        tvAvailableSpace = findViewById(R.id.tvAvailableSpace);

        Button btnUpdateSpace = findViewById(R.id.btnUpdateSpace);

        btnUpdateSpace.setOnClickListener(v -> {
            String totalText = etTotalCapacity.getText().toString().trim();
            String occupiedText = etOccupiedSpace.getText().toString().trim();

            if (totalText.isEmpty() || occupiedText.isEmpty()) {
                Toast.makeText(this, "Please enter both values",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double total = Double.parseDouble(totalText);
                double occupied = Double.parseDouble(occupiedText);

                if (total <= 0 || occupied < 0 || occupied > total) {
                    Toast.makeText(this,
                            "Check capacity and occupied space",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                double available = total - occupied;
                tvAvailableSpace.setText(
                        "Available space: " + available + " tons");

                Toast.makeText(this,
                        "Space calculated. Save to database will be connected later.",
                        Toast.LENGTH_SHORT).show();

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Enter valid numbers",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
