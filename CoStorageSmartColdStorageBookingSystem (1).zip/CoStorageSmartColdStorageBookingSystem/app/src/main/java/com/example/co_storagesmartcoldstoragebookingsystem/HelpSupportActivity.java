
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class HelpSupportActivity extends AppCompatActivity {

    Button btnBackHelp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_support);

        btnBackHelp = findViewById(R.id.btnBackHelp);

        btnBackHelp.setOnClickListener(v -> finish());
    }
}
