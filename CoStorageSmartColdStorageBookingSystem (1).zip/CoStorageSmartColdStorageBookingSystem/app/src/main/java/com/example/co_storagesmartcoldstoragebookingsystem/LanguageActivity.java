
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LanguageActivity extends AppCompatActivity {

    String selectedLanguage = "English";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        Button btnEnglish = findViewById(R.id.btnEnglish);
        Button btnGujarati = findViewById(R.id.btnGujarati);
        Button btnContinue = findViewById(R.id.btnContinue);

        btnEnglish.setOnClickListener(v -> {
            selectedLanguage = "English";
            Toast.makeText(this, "English selected",
                    Toast.LENGTH_SHORT).show();
        });

        btnGujarati.setOnClickListener(v -> {
            selectedLanguage = "Gujarati";
            Toast.makeText(this, "ગુજરાતી પસંદ કરી",
                    Toast.LENGTH_SHORT).show();
        });

        btnContinue.setOnClickListener(v -> {
            Intent intent = new Intent(
                    LanguageActivity.this,
                    LoginActivity.class
            );
            startActivity(intent);
        });
    }
}
