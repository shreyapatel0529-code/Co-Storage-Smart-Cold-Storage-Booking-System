
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MyStoragesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_storages);

        Button btnAddAnotherStorage = findViewById(R.id.btnAddAnotherStorage);
        Button btnUpdateStorageSpace = findViewById(R.id.btnUpdateStorageSpace);

        btnAddAnotherStorage.setOnClickListener(v ->
                startActivity(new Intent(this, AddStorageActivity.class)));

        btnUpdateStorageSpace.setOnClickListener(v ->
                startActivity(new Intent(this, UpdateSpaceActivity.class)));
    }
}
