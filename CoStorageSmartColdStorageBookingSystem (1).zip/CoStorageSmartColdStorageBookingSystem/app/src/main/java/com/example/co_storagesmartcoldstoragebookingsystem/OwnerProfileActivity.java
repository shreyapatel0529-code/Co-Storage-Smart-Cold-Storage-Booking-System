
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class OwnerProfileActivity extends AppCompatActivity {

    Button btnEditOwnerProfile, btnOwnerNotifications, btnOwnerHelp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_profile);

        btnEditOwnerProfile = findViewById(R.id.btnEditOwnerProfile);
        btnOwnerNotifications = findViewById(R.id.btnOwnerNotifications);
        btnOwnerHelp = findViewById(R.id.btnOwnerHelp);

        btnEditOwnerProfile.setOnClickListener(v -> {
            Intent intent = new Intent(
                    OwnerProfileActivity.this,
                    EditProfileActivity.class
            );
            startActivity(intent);
        });

        btnOwnerNotifications.setOnClickListener(v -> {
            Intent intent = new Intent(
                    OwnerProfileActivity.this,
                    NotificationsActivity.class
            );
            startActivity(intent);
        });

        btnOwnerHelp.setOnClickListener(v -> {
            Intent intent = new Intent(
                    OwnerProfileActivity.this,
                    HelpSupportActivity.class
            );
            startActivity(intent);
        });
    }
}
