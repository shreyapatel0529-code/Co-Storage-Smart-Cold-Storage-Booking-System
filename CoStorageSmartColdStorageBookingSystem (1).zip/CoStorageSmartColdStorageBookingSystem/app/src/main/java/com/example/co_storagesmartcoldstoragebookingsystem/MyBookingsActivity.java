
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MyBookingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_bookings);

        Button btnFindStorage = findViewById(R.id.btnFindStorage);

        btnFindStorage.setOnClickListener(v ->
                startActivity(new Intent(this, SearchStorageActivity.class)));
    }
}
