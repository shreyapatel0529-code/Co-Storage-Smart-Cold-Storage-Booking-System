
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class FarmerHomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_home);

        Button btnSearchStorage = findViewById(R.id.btnSearchStorage);
        Button btnMyBookings = findViewById(R.id.btnMyBookings);
        Button btnFarmerProfile = findViewById(R.id.btnFarmerProfile);

        btnSearchStorage.setOnClickListener(v ->
                startActivity(new Intent(this, SearchStorageActivity.class)));

        btnMyBookings.setOnClickListener(v ->
                startActivity(new Intent(this, MyBookingsActivity.class)));

        btnFarmerProfile.setOnClickListener(v ->
                startActivity(new Intent(this, FarmerProfileActivity.class)));
    }
}
