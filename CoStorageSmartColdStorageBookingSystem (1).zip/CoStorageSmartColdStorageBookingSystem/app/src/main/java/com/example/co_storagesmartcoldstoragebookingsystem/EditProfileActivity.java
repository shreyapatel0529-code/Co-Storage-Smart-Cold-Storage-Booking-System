
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditProfileActivity extends AppCompatActivity {

    EditText etEditName, etEditEmail, etEditPhone;
    Button btnSaveProfile, btnCancelProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        etEditName = findViewById(R.id.etEditName);
        etEditEmail = findViewById(R.id.etEditEmail);
        etEditPhone = findViewById(R.id.etEditPhone);

        btnSaveProfile = findViewById(R.id.btnSaveProfile);
        btnCancelProfile = findViewById(R.id.btnCancelProfile);

        btnSaveProfile.setOnClickListener(v -> saveProfile());

        btnCancelProfile.setOnClickListener(v -> finish());
    }

    private void saveProfile() {
        String name = etEditName.getText().toString().trim();
        String email = etEditEmail.getText().toString().trim();
        String phone = etEditPhone.getText().toString().trim();

        if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this,
                    "Please fill in all fields",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEditEmail.setError("Enter a valid email address");
            return;
        }

        if (!phone.matches("[0-9]{10}")) {
            etEditPhone.setError("Enter a 10-digit mobile number");
            return;
        }

        Toast.makeText(this,
                "Details validated. Profile saving will be connected later.",
                Toast.LENGTH_LONG).show();
    }
}
