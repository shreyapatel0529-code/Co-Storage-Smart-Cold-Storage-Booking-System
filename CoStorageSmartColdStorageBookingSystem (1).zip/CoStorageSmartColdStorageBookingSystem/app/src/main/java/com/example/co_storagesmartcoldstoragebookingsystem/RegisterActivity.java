
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class RegisterActivity extends AppCompatActivity {

    private EditText etName, etRegisterEmail, etPhone, etRegisterPassword;
    private Spinner spinnerRole;
    private Button btnCreateAccount;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        databaseHelper = new DatabaseHelper(this);

        etName = findViewById(R.id.etName);
        etRegisterEmail = findViewById(R.id.etRegisterEmail);
        etPhone = findViewById(R.id.etPhone);
        etRegisterPassword = findViewById(R.id.etRegisterPassword);
        spinnerRole = findViewById(R.id.spinnerRole);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        String[] roles = {"Farmer", "Cold Storage Owner"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                roles
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        spinnerRole.setAdapter(adapter);

        btnCreateAccount.setOnClickListener(v -> registerUser());
    }

    private void registerUser() {

        String name = etName.getText().toString().trim();
        String email = etRegisterEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String password = etRegisterPassword.getText().toString();
        String role = spinnerRole.getSelectedItem().toString();

        if (name.isEmpty() || email.isEmpty()
                || phone.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please fill in all fields",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etRegisterEmail.setError("Enter a valid email address");
            etRegisterEmail.requestFocus();
            return;
        }

        if (!phone.matches("[0-9]{10}")) {
            etPhone.setError("Enter a valid 10-digit phone number");
            etPhone.requestFocus();
            return;
        }

        if (password.length() < 8) {
            etRegisterPassword.setError(
                    "Password must contain at least 8 characters");
            etRegisterPassword.requestFocus();
            return;
        }

        String passwordHash = hashPassword(password);

        if (passwordHash == null) {
            Toast.makeText(this,
                    "Unable to create account",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        long result = databaseHelper.addUser(
                name,
                email,
                phone,
                passwordHash,
                role
        );

        if (result != -1) {
            Toast.makeText(this,
                    "Registration successful! Please log in.",
                    Toast.LENGTH_LONG).show();

            Intent intent = new Intent(
                    RegisterActivity.this, LoginActivity.class);

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
                            | Intent.FLAG_ACTIVITY_SINGLE_TOP);

            startActivity(intent);
            finish();

        } else {
            Toast.makeText(this,
                    "Registration failed. This email may already exist.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            byte[] bytes = digest.digest(
                    password.getBytes(StandardCharsets.UTF_8));

            StringBuilder result = new StringBuilder();

            for (byte b : bytes) {
                result.append(String.format("%02x", b & 0xff));
            }

            return result.toString();

        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }
}
