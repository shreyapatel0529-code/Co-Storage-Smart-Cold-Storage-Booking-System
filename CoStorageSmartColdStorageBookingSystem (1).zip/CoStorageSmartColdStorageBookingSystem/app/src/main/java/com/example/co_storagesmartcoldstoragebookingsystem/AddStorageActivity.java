
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddStorageActivity extends AppCompatActivity {

    EditText etStorageName, etStorageAddress, etStoragePincode;
    EditText etStorageCapacity, etStorageRate, etSuitableCrops;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_storage);

        etStorageName = findViewById(R.id.etStorageName);
        etStorageAddress = findViewById(R.id.etStorageAddress);
        etStoragePincode = findViewById(R.id.etStoragePincode);
        etStorageCapacity = findViewById(R.id.etStorageCapacity);
        etStorageRate = findViewById(R.id.etStorageRate);
        etSuitableCrops = findViewById(R.id.etSuitableCrops);

        Button btnSaveStorage = findViewById(R.id.btnSaveStorage);

        btnSaveStorage.setOnClickListener(v -> {
            String name = etStorageName.getText().toString().trim();
            String address = etStorageAddress.getText().toString().trim();
            String pincode = etStoragePincode.getText().toString().trim();
            String capacity = etStorageCapacity.getText().toString().trim();
            String rate = etStorageRate.getText().toString().trim();
            String crops = etSuitableCrops.getText().toString().trim();

            if (name.isEmpty() || address.isEmpty()
                    || pincode.length() != 6 || capacity.isEmpty()
                    || rate.isEmpty() || crops.isEmpty()) {
                Toast.makeText(this,
                        "Please fill all fields correctly",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double totalCapacity = Double.parseDouble(capacity);
                double monthlyRate = Double.parseDouble(rate);

                if (totalCapacity <= 0 || monthlyRate <= 0) {
                    Toast.makeText(this,
                            "Capacity and rate must be greater than zero",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this,
                        "Enter valid capacity and rate",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            Toast.makeText(this,
                    "Form validated. Database saving will be connected later.",
                    Toast.LENGTH_LONG).show();
        });
    }
}
