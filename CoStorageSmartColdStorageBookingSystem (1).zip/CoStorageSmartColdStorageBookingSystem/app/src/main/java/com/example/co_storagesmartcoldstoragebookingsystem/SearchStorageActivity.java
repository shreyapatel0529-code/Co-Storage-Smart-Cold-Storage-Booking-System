
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SearchStorageActivity extends AppCompatActivity {

    EditText etPincode, etCropType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_storage);

        etPincode = findViewById(R.id.etPincode);
        etCropType = findViewById(R.id.etCropType);

        Button btnSearch = findViewById(R.id.btnSearch);

        btnSearch.setOnClickListener(v -> {
            String pincode = etPincode.getText().toString().trim();
            String crop = etCropType.getText().toString().trim();

            if (pincode.length() != 6) {
                etPincode.setError("Enter a valid 6-digit PIN code");
                return;
            }

            Intent intent = new Intent(
                    SearchStorageActivity.this,
                    StorageListActivity.class
            );

            intent.putExtra("pincode", pincode);
            intent.putExtra("crop", crop);
            startActivity(intent);
        });
    }
}
