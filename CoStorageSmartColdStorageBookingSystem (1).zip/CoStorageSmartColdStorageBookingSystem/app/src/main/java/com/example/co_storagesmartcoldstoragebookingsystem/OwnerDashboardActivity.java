
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class OwnerDashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_dashboard);

        Button btnAddStorage = findViewById(R.id.btnAddStorage);
        Button btnMyStorages = findViewById(R.id.btnMyStorages);
        Button btnBookingRequests = findViewById(R.id.btnBookingRequests);
        Button btnOwnerProfile = findViewById(R.id.btnOwnerProfile);

        btnAddStorage.setOnClickListener(v ->
                startActivity(new Intent(this, AddStorageActivity.class)));

        btnMyStorages.setOnClickListener(v ->
                startActivity(new Intent(this, MyStoragesActivity.class)));

        btnBookingRequests.setOnClickListener(v ->
                startActivity(new Intent(this, BookingRequestsActivity.class)));

        btnOwnerProfile.setOnClickListener(v ->
                startActivity(new Intent(this, OwnerProfileActivity.class)));
    }
}
