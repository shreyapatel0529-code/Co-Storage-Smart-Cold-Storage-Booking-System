
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class StorageListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_storage_list);

        String pincode = getIntent().getStringExtra("pincode");
        String crop = getIntent().getStringExtra("crop");

        TextView heading = findViewById(R.id.storageHeading);
        Button btnViewStorage1 = findViewById(R.id.btnViewStorage1);

        if (heading != null && pincode != null) {
            heading.setText("Search results for PIN: " + pincode);
        }

        btnViewStorage1.setOnClickListener(v -> {
            Intent intent = new Intent(
                    StorageListActivity.this,
                    StorageDetailsActivity.class
            );
            intent.putExtra("pincode", pincode);
            intent.putExtra("crop", crop);
            startActivity(intent);
        });
    }
}
