
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class BookingRequestsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_requests);

        Button btnAcceptBooking = findViewById(R.id.btnAcceptBooking);
        Button btnRejectBooking = findViewById(R.id.btnRejectBooking);

        btnAcceptBooking.setOnClickListener(v ->
                Toast.makeText(this,
                        "No saved request to accept yet",
                        Toast.LENGTH_SHORT).show());

        btnRejectBooking.setOnClickListener(v ->
                Toast.makeText(this,
                        "No saved request to reject yet",
                        Toast.LENGTH_SHORT).show());
    }
}
