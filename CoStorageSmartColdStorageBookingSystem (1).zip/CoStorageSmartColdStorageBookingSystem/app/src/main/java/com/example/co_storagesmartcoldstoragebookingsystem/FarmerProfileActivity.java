
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class FarmerProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_profile);

        Button btnEditFarmerProfile =
                findViewById(R.id.btnEditFarmerProfile);
        Button btnFarmerHelp = findViewById(R.id.btnFarmerHelp);

        btnEditFarmerProfile.setOnClickListener(v ->
                startActivity(new Intent(this, EditProfileActivity.class)));

        btnFarmerHelp.setOnClickListener(v ->
                startActivity(new Intent(this, HelpSupportActivity.class)));
    }
}
