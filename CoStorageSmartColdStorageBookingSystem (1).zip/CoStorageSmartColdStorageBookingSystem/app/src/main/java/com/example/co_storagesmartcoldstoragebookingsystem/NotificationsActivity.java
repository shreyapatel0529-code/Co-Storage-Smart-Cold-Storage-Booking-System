
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class NotificationsActivity extends AppCompatActivity {

    Button btnBackNotifications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        btnBackNotifications = findViewById(R.id.btnBackNotifications);

        btnBackNotifications.setOnClickListener(v -> finish());
    }
}
