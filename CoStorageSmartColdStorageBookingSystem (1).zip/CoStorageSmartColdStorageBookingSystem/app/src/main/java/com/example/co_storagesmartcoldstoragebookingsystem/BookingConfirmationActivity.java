
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class BookingConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_confirmation);

        TextView tvBookingSummary = findViewById(R.id.tvBookingSummary);
        Button btnGoToBookings = findViewById(R.id.btnGoToBookings);

        String crop = getIntent().getStringExtra("crop");
        String quantity = getIntent().getStringExtra("quantity");
        String date = getIntent().getStringExtra("date");
        String duration = getIntent().getStringExtra("duration");

        String summary = "Crop: " + crop
                + "\nQuantity: " + quantity + " tons"
                + "\nStart date: " + date
                + "\nDuration: " + duration + " days"
                + "\n\nThis is a booking request, not a confirmed reservation.";

        tvBookingSummary.setText(summary);

        btnGoToBookings.setOnClickListener(v -> {
            Intent intent = new Intent(
                    BookingConfirmationActivity.this,
                    MyBookingsActivity.class
            );
            startActivity(intent);
        });
    }
}
