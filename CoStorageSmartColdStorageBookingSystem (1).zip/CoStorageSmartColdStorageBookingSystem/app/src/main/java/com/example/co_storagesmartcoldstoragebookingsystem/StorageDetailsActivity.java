
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class StorageDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_storage_details);

        Button btnBookStorage = findViewById(R.id.btnBookStorage);

        btnBookStorage.setOnClickListener(v -> {
            Intent intent = new Intent(
                    StorageDetailsActivity.this,
                    BookingActivity.class
            );
            intent.putExtra(
                    "pincode",
                    getIntent().getStringExtra("pincode")
            );
            intent.putExtra(
                    "crop",
                    getIntent().getStringExtra("crop")
            );
            startActivity(intent);
        });
    }
}
