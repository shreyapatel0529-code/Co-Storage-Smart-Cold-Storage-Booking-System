
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CoStorage.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "email TEXT NOT NULL UNIQUE, " +
                "phone TEXT, " +
                "password_hash TEXT NOT NULL, " +
                "role TEXT NOT NULL)");

        db.execSQL("CREATE TABLE storages (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "owner_id INTEGER NOT NULL, " +
                "name TEXT NOT NULL, " +
                "address TEXT NOT NULL, " +
                "pincode TEXT NOT NULL, " +
                "capacity REAL NOT NULL, " +
                "occupied REAL DEFAULT 0, " +
                "rate REAL NOT NULL, " +
                "crops TEXT, " +
                "FOREIGN KEY(owner_id) REFERENCES users(id))");

        db.execSQL("CREATE TABLE bookings (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "farmer_id INTEGER NOT NULL, " +
                "storage_id INTEGER NOT NULL, " +
                "crop TEXT NOT NULL, " +
                "quantity REAL NOT NULL, " +
                "start_date TEXT, " +
                "duration_days INTEGER NOT NULL, " +
                "status TEXT DEFAULT 'Pending', " +
                "FOREIGN KEY(farmer_id) REFERENCES users(id), " +
                "FOREIGN KEY(storage_id) REFERENCES storages(id))");

        db.execSQL("CREATE TABLE notifications (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "message TEXT NOT NULL, " +
                "is_read INTEGER DEFAULT 0, " +
                "created_at TEXT DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY(user_id) REFERENCES users(id))");

        db.execSQL("CREATE TABLE preferences (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER UNIQUE, " +
                "language TEXT DEFAULT 'English', " +
                "FOREIGN KEY(user_id) REFERENCES users(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        // Add database migration code here when the schema changes.
    }

    // Register a user. Store a secure password hash, never a plain password.
    public long addUser(String name, String email, String phone,
                        String passwordHash, String role) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name.trim());
        values.put("email", email.trim().toLowerCase());
        values.put("phone", phone);
        values.put("password_hash", passwordHash);
        values.put("role", role);

        try {
            return db.insertOrThrow("users", null, values);
        } catch (android.database.SQLException e) {
            return -1;
        }
    }

    // Find a user by email.
    public Cursor getUserByEmail(String email) {
        return getReadableDatabase().query(
                "users",
                new String[]{"id", "name", "email", "phone",
                        "password_hash", "role"},
                "email = ?",
                new String[]{email.trim().toLowerCase()},
                null, null, null
        );
    }

    // Add cold storage details.
    public long addStorage(int ownerId, String name, String address,
                           String pincode, double capacity,
                           double rate, String crops) {

        if (capacity <= 0 || rate < 0 ||
                pincode == null || !pincode.matches("[0-9]{6}")) {
            return -1;
        }

        ContentValues values = new ContentValues();
        values.put("owner_id", ownerId);
        values.put("name", name);
        values.put("address", address);
        values.put("pincode", pincode);
        values.put("capacity", capacity);
        values.put("occupied", 0);
        values.put("rate", rate);
        values.put("crops", crops);

        return getWritableDatabase().insert("storages", null, values);
    }

    // Get all cold storages for a PIN code.
    public Cursor getStoragesByPincode(String pincode) {
        return getReadableDatabase().query(
                "storages", null,
                "pincode = ?",
                new String[]{pincode},
                null, null, "name ASC"
        );
    }

    // Get all storages owned by a user.
    public Cursor getStoragesByOwner(int ownerId) {
        return getReadableDatabase().query(
                "storages", null,
                "owner_id = ?",
                new String[]{String.valueOf(ownerId)},
                null, null, "id DESC"
        );
    }

    // Update occupied capacity.
    public boolean updateSpace(int storageId, double occupied) {
        if (occupied < 0) return false;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("occupied", occupied);

        int updated = db.update(
                "storages", values,
                "id = ? AND capacity >= ?",
                new String[]{String.valueOf(storageId),
                        String.valueOf(occupied)}
        );

        return updated > 0;
    }

    // Create a booking request.
    public long addBooking(int farmerId, int storageId, String crop,
                           double quantity, String startDate,
                           int durationDays) {

        if (quantity <= 0 || durationDays <= 0) return -1;

        ContentValues values = new ContentValues();
        values.put("farmer_id", farmerId);
        values.put("storage_id", storageId);
        values.put("crop", crop);
        values.put("quantity", quantity);
        values.put("start_date", startDate);
        values.put("duration_days", durationDays);
        values.put("status", "Pending");

        return getWritableDatabase().insert("bookings", null, values);
    }

    // Get booking records for a farmer.
    public Cursor getBookingsByFarmer(int farmerId) {
        return getReadableDatabase().rawQuery(
                "SELECT b.*, s.name AS storage_name " +
                        "FROM bookings b " +
                        "JOIN storages s ON b.storage_id = s.id " +
                        "WHERE b.farmer_id = ? ORDER BY b.id DESC",
                new String[]{String.valueOf(farmerId)}
        );
    }

    // Get booking requests for a particular storage owner.
    public Cursor getBookingsByOwner(int ownerId) {
        return getReadableDatabase().rawQuery(
                "SELECT b.*, s.name AS storage_name, u.name AS farmer_name " +
                        "FROM bookings b " +
                        "JOIN storages s ON b.storage_id = s.id " +
                        "JOIN users u ON b.farmer_id = u.id " +
                        "WHERE s.owner_id = ? ORDER BY b.id DESC",
                new String[]{String.valueOf(ownerId)}
        );
    }

    // Accept or reject a booking request.
    public boolean updateBookingStatus(int bookingId, String status) {
        if (!"Accepted".equals(status) &&
                !"Rejected".equals(status)) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("status", status);

        return getWritableDatabase().update(
                "bookings", values,
                "id = ? AND status = 'Pending'",
                new String[]{String.valueOf(bookingId)}
        ) > 0;
    }

    // Add a notification for a user.
    public long addNotification(int userId, String message) {
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("message", message);

        return getWritableDatabase().insert(
                "notifications", null, values);
    }

    // Get notifications for a user.
    public Cursor getNotifications(int userId) {
        return getReadableDatabase().query(
                "notifications", null,
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null, null, "id DESC"
        );
    }

    // Save the selected language for a user.
    public boolean saveLanguage(int userId, String language) {
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("language", language);

        return getWritableDatabase().insertWithOnConflict(
                "preferences", null, values,
                SQLiteDatabase.CONFLICT_REPLACE
        ) != -1;
    }
}
