
package com.example.co_storagesmartcoldstoragebookingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class BookingActivity extends AppCompatActivity {

    EditText etCropName, etQuantity, etStartDate, etDuration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        etCropName = findViewById(R.id.etCropName);
        etQuantity = findViewById(R.id.etQuantity);
        etStartDate = findViewById(R.id.etStartDate);
        etDuration = findViewById(R.id.etDuration);

        Button btnConfirmBooking = findViewById(R.id.btnConfirmBooking);

        btnConfirmBooking.setOnClickListener(v -> {
            String crop = etCropName.getText().toString().trim();
            String quantity = etQuantity.getText().toString().trim();
            String date = etStartDate.getText().toString().trim();
            String duration = etDuration.getText().toString().trim();

            if (crop.isEmpty() || quantity.isEmpty()
                    || date.isEmpty() || duration.isEmpty()) {
                Toast.makeText(this, "Please fill all fields",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double tons = Double.parseDouble(quantity);
                int days = Integer.parseInt(duration);

                if (tons <= 0 || days <= 0) {
                    Toast.makeText(this,
                            "Quantity and duration must be greater than zero",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Enter valid quantity and duration",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(
                    BookingActivity.this,
                    BookingConfirmationActivity.class
            );

            intent.putExtra("crop", crop);
            intent.putExtra("quantity", quantity);
            intent.putExtra("date", date);
            intent.putExtra("duration", duration);

            startActivity(intent);
        });
    }
}
